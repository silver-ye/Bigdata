xh = input("Ener Hours: ")
xr = input("Ener Rate: ")
xp = float(xh) * float(xr)
print("Pay:",xp)
