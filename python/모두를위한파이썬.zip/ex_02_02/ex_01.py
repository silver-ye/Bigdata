print('Tell me why!')
