nzt = input('Enter your name: ')
print('Hello', nzt)
