def computepay(hours, rate) :
    #print("In computepay", hours, rate)
    if hours > 40 :
        # print("Overtime")
        reg = hours * rate
        otp = (hours - 40.0) * (rate * 0.5)
        # print(reg, otp)
        pay = reg + otp
    else :
        # print("Regular")
        pay = hours * rate
    #print("Returning", pay)
    return pay

sh = input("Ener Hours: ")
sr = input("Ener Rate: ")
fh = float(sh)
fr = float(sr)
# print(fh, fr)
xp = computepay(fh,fr)

print("Pay:",xp)
