fname = input("Enter file name: ")
fh = open(fname)
count = 0
total = 0
for line in fh:
    line = line.rstrip()
    if not line.startswith("X-DSPAM-Confidence:") : continue

    else:
        ip = line.find(':')
        pi = line[ip+2: ]
        val = float(pi)
        count = count + 1
        total = total + val

print("average ", total/count)
