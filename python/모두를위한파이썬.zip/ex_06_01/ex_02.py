words = 'Connect Foundation'

if 'F' in words :
    words.lower()
    words[7] = '&'
else :
    print(words)
print(words)
