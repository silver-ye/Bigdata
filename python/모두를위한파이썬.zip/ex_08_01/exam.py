words = ['Hello', 'world']

words.append(['connect', 'word'])

print(words)
print(len(words))
