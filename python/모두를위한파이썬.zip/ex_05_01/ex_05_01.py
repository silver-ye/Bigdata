count = 0
sum = 0
while True :
    line = input("Enter a number: ")
    if line  == 'done' :
        break
    try :
        val = float(line)
    except :
        print("Invalid input")
        continue

    count = count + 1
    sum = sum + val

print(sum, count, sum / count)
