largest = None
smallest = None
while True :
    lin = input("Enter a number: ")
    if lin  == 'done' :
        break
    try :
        val = float(lin)
    except :
        print("Invalid input")
        continue

    if smallest == None:
        smallest = val
    elif val < smallest:
        smallest = val
    if largest == None:
        largest = val
    elif val > largest:
        largest = val

largest = int(largest)
smallest = int(smallest)
print('Maximum is', largest)
print('Minimum is', smallest)
