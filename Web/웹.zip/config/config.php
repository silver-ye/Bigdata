<?php
$config = array(
  "host"=> "localhost",
  "duser"=> "root",
  "dpw"=> "sef5532",
  "dname"=> "opentutorials"
);

 ?>
