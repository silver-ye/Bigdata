<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
</head>
<body>
  <h1>JavaScript</h1>
    <ul>
    <script>
    i = 0;
    while(i < 2) {
      document.write("<li>hello world</li>");
      i = i + 1;
    }
    </script>
    </ul>

  <h2>php</h2>
    <?php
    $i = 0;
    while($i < 2) {
      echo "hello world<br />";
      $i = $i + 1;
    }
    ?>
</body>
</html>
