<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
</head>
<body>
  <?php
    $password = $_GET['password'];
    if($password == "1111") {
      echo "안녕하세요";
    } else {
      echo "사용자가 아닙니다.";
    }
   ?>
</body>
</html>
