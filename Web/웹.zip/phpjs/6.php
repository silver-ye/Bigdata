<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
</head>
<body>
  <h1>Javascript</h1>
  <script>
    result = (1==1);
    if(result){
      document.write("참");
    } else {
      document.write("거짓");
    }
  </script>
<h1>php</h1>
  <?php
    $result = (1==2);
    if($result) {
      echo "참";
    } else {
      echo "거짓";
    }
   ?>
</body>
</html>
