<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
</head>
<body>
  <h1>javascript</h1>
  <script charset="utf-8">
    name = "egoing";
    document.write("안녕하세요"+name);
  </script>
  <h1>php</h1>
  <?php
    $name = "egoing";
    echo "안녕하세요.".$name;
   ?>0
</body>
</html>
