<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <<?php
      echo htmlspecialchars('<a href="http://naver.com">네이버</a>');
    ?>
  </body>
</html>
